﻿namespace JwtWebApiTutorial.Services.UserService
{
    public interface IUserService
    {
        string GetMyName();
    }
}
